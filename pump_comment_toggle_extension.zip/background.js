chrome.action.onClicked.addListener((tab) => {
  chrome.storage.local.get(["commentsEnabled"], (res) => {
    const newState = !(res.commentsEnabled ?? true);
    chrome.storage.local.set({ commentsEnabled: newState }, () => {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
    });
  });
});
